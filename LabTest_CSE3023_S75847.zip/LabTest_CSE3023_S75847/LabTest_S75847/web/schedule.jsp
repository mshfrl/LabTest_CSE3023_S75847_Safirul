<%-- 
    Document   : schedule
    Created on : 16 Jun 2026, 3:22:04 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>View Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>


<%@include file="header.html" %>
<body class="container mt-5">
    <h2 class="mb-4">Booking View</h2>
    
    <table class="table table-bordered table-striped shadow-sm">
        <thead class="table-dark">
            <tr>
                <th>Session ID</th>
                <th>Student Name</th>
                <th>Branch Location</th>
                <th>Lesson Type</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="session" items="${sessionList}">
                <tr>
                    <td><c:out value="${session.id}" /></td>
                    <td><c:out value="${session.student_name}" /></td>
                    <td><c:out value="${session.branch_location}" /></td>
                    <td><c:out value="${session.lesson_type}" /></td>
                    <td><c:out value="${session.status}" /></td>
                    <td>
                        <a href="ScheduleServlet?action=delete&id=${session.id}" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this booking?');">
                           Delete
                        </a>
                    </td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
    
    <a href="book_session.jsp" class="btn btn-primary mt-3">Book Another Session</a>
    
</body>
</html>
