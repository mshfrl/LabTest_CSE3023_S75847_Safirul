<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 3:14:14 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Book Session</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    
    <%@include file="header.html" %>
    
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h2 class="mb-4">Session Booking</h2>
            <form action="BookSessionServlet" method="post" class="card p-4 shadow-sm">
                <div class="mb-3">
                    <label class="form-label">Name:</label>
                    <input type="text" name="student_name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Branch Location:</label>
                    <input type="text" name="branch_location" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Lesson Type:</label>
                    <select name="lesson_type" class="form-select">
                        <option value="manual">Manual Car</option>
                        <option value="auto">Automatic Car</option>
                        <option value="moto">Motorcycle</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Book</button>
            </form>
            <div class="mt-3 text-center">
                <a href="ScheduleServlet" class="btn btn-outline-secondary">View Booking</a>
            </div>
        </div>
    </div>
    
    <%@include file="footer.jsp" %>
</body>
</html>
