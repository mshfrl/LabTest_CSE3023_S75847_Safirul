<%-- 
    Document   : footer
    Created on : 16 Jun 2026, 3:43:41 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>footer</title>
    </head>
    <body>
        <div>Smart Drive Class &copy; 2026</div>
        <%= new java.util.Date() %>
    </body>
</html>
